from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models
import re

def validate_phone(value):
    digits = re.sub(r'\D', '', str(value))   # оставляем только цифры
    if not re.match(r'^[78]\d{10}$', digits):
        raise ValidationError('Телефон должен содержать 11 цифр и начинаться с 8 или +7')

def validate_cyrillic(value):
    if not all(c.isalpha() or c.isspace() for c in value):
        raise ValueError('ФИО должно содержать только символы кирилицы и пробелы')

class CustomUser(AbstractUser):
    username = models.CharField(
        max_length=150,
        unique=True,
        verbose_name='Логин',
        help_text='Только латиница и цифры, не менее 6 символов'
    )
    password = models.CharField(
        max_length=128,
        verbose_name='Пароль'
    )
    fullname = models.CharField(
        max_length=255,
        verbose_name='ФИО',
        validators=[validate_cyrillic]
    )
    phone = models.CharField(
        max_length=20,
        verbose_name='Телефон',
        validators=[validate_phone]
    )
    email = models.EmailField(
        max_length=254,
        verbose_name='Электронная почта'
    )
    is_admin = models.BooleanField(default=False, verbose_name='Администратор')

    groups = models.ManyToManyField(
        'auth.Group',
        related_name='customuser_set',
        blank=True,
        verbose_name='Группы',
        help_text='Группы к которым данный пользователь принадлежит.'
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        related_name='customuser_set',
        blank=True,
        verbose_name='Разрешения пользователя',
        help_text='Особые разрешения для данного пользователя.'
    )

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'